
# 🤖 Deriv Over 3 Bot (Avançado)

Este robô opera na Deriv com base na estratégia Over 3 e conta com controle total:

- Entrada baseada nos últimos 8 dígitos
- Controle de take profit e stop loss
- Multiplicador configurável após 2 perdas
- Interface via Streamlit

## Como usar
1. Suba este projeto no GitHub
2. Conecte no Streamlit Cloud (https://streamlit.io/cloud)
3. Defina os parâmetros e inicie o robô

Recomenda-se uso em conta virtual para testes.
