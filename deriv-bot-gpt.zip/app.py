# Streamlit interface principal
print('App iniciado')