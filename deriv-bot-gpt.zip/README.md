# Bot Deriv com WebSocket e Martingale

Instruções para executar via Streamlit.