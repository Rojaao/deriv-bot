# app.py - Interface Streamlit com conexão Deriv WebSocket, 6em7Digit e mais
