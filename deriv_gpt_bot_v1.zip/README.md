# Deriv GPT Bot
Este robô opera automaticamente na Deriv com estratégias configuráveis via WebSocket.