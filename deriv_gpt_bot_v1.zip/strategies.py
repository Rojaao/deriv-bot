# strategies.py - Define estratégias como 6em7Digit, Digit Match, Over/Under
