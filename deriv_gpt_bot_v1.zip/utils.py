# utils.py - Funções auxiliares (análise de ticks, martingale, logs)
