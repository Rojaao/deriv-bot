# Estratégias disponíveis: 6em7Digit, Digit Over/Under, Match/Diff, etc.
