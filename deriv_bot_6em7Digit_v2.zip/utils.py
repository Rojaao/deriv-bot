# Funções auxiliares para análise de ticks e controle de ordens
