# Código principal do robô com conexão WebSocket aprimorada e estratégia 6em7Digit
