# Interface principal com Streamlit
print('App iniciado com histórico')