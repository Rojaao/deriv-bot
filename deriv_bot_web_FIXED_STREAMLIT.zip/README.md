# Deriv Bot GPT Web
Versão compatível com Streamlit Cloud.
